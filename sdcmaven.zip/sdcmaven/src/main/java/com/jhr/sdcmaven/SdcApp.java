package com.jhr.sdcmaven;

public class SdcApp 
{
	static SdcView view;
	static SdcModel model;
	static SdcController controller;
	
	public static void main(String[] args) 
	{
		view = new SdcView();
		model = new SdcModel( view );
		controller = new SdcController( model );
		
		if (args.length > 0) 
		{
			controller.inputCommand( args[0] );		
		}
		else
		{
			view.showComment("File name required on the command line.");
		}
			
	}


	

}

package com.jhr.sdcmaven;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.commons.math3.primes.Primes;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class SdcModel 
{
	SdcView view;
	
	public SdcModel  ( SdcView v )
	{
		view = v;
	}
	
	public void analyzeExcelFile(String fname) {
		try
		{
			FileInputStream fis = new FileInputStream(new File(fname));
			
			try {
				XSSFWorkbook wb = new XSSFWorkbook(fis);
				dispatchExcelPrimesXSSF(wb);
			} catch (Exception e) {
				if ( view != null )
					view.showError(e);

				fis = new FileInputStream(new File(fname));
				HSSFWorkbook wb = new HSSFWorkbook(fis);
				dispatchExcelPrimesHSSF(wb);
			}
		}
		catch (IOException e)
		{
			if ( view != null  )
				view.showError(e);
		}
	}

	public long convertDoubleToUnsignedLong( double d ) 
	{
		try
		{
			double fn = Math.floor(d);
			if ( fn != d )
				return -1;  // WITH DECIMAL PART
			return (long) d;
		}
		catch ( Exception e )
		{
			if ( view != null  )
				view.showError(e);
			return -1;
		}
	}
	
	//returns -1 if error
	public long convertStringToUnsignedLong( String s )
	{
		try
		{
		    double d = Double.parseDouble( s );  
			return convertDoubleToUnsignedLong( d );
		}
		catch ( Exception e )
		{
			//ignore not valid data
			return -1;
		}
	}


	public boolean isPrimeNumber(long n) 
	{
		try
		{
			return Primes.isPrime((int) n);
		}
		catch ( Exception e )
		{
			if ( view != null  )
				view.showError(e);
			return false;
		}
	}

	public void dispatchExcelPrimesXSSF(XSSFWorkbook wb) 
	{
		XSSFSheet sheet = wb.getSheetAt(0);

		FormulaEvaluator formulaEvaluator = wb.getCreationHelper().createFormulaEvaluator();
		for (Row row : sheet) 
		{
			//DATA ARE IN THE COLUMN "B"
			dispatchCell( row.getCell(1), formulaEvaluator );
			/*
			//DATA ARE EVERYWHERE
			for (Cell cell : row) 
			{
				dispatcHCell( cell, formulaEvaluator );
			}
			*/
		}
	}

	public void dispatchExcelPrimesHSSF(HSSFWorkbook wb) {
		HSSFSheet sheet = wb.getSheetAt(0);

		FormulaEvaluator formulaEvaluator = wb.getCreationHelper().createFormulaEvaluator();
		for (Row row : sheet) 
		{
			//DATA IS IN THE COLUMN "B"
			dispatchCell( row.getCell(1), formulaEvaluator );
			/*
			//DATA ARE EVERYWHERE
			for (Cell cell : row) 
			{
				dispatcHCell( cell, formulaEvaluator );
			}
			*/
		}
	}
	

	public void dispatchCell( Cell cell, FormulaEvaluator formulaEvaluator ) 
	{
		long n;
		CellType ct = formulaEvaluator.evaluateInCell(cell).getCellType();
		switch ( ct ) {
		case NUMERIC:
			double d = cell.getNumericCellValue();
			n = convertDoubleToUnsignedLong(d);
			if (isPrimeNumber(n))
			{
				if ( view != null  )
					view.showValue(n);
			}
			break;
		case STRING:
			String s = cell.getStringCellValue();
			try {
				n = convertStringToUnsignedLong(s);
				if (isPrimeNumber(n))
				{
					if ( view != null  )
						view.showValue(n);
				}
			} catch (Exception e) {
				if ( view != null  )
					view.showError(e);
			}
			break;
		default:
			break;
		}
		
	}

}

package com.jhr.sdcmaven;

public class SdcView {

	public void showValue( long val )
	{
		System.out.println( val);
	}
	

	public void showError( Exception e )
	{
		System.out.println( e  );
	}


	public void showComment( String s )
	{
		System.out.println( s );
	}

}

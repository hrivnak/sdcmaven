package com.jhr.sdcmaven;

public class SdcController {
	SdcModel sdcModel;
	
	public SdcController ( SdcModel model )
	{
		sdcModel = model;
	}
	
	void inputCommand( String cmd )
	{
		sdcModel.analyzeExcelFile( cmd );
	}

}

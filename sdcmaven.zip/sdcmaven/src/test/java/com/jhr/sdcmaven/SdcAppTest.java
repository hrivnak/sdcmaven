package com.jhr.sdcmaven;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class SdcAppTest 
{

    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
    
    @Test
    public void shouldConstructObjects()
    {
    	SdcView view = new SdcView();
    	SdcModel model = new SdcModel( view );
		SdcController controller = new SdcController( model );
		
        assertNotNull( view );
        assertNotNull( model );
        assertNotNull( controller );
    }
    
    @Test
    public void shouldBePrimeNumber() 
    {
    	SdcModel model = new SdcModel( null );
    	assertFalse( model.isPrimeNumber( -1 ) );
    	assertFalse( model.isPrimeNumber( 0 ) );
    	assertFalse( model.isPrimeNumber( 1 ) );
    	assertFalse( model.isPrimeNumber( 1 ) );
    	assertTrue( model.isPrimeNumber( 2 ) );
    	assertTrue( model.isPrimeNumber( 3 ) );
    	assertFalse( model.isPrimeNumber( 4 ) );
    	assertTrue( model.isPrimeNumber( 5 ) );
    	assertTrue( model.isPrimeNumber( 5 ) );
    }

    @Test
    public void shouldBeUnsignedLong() 
    {
    	SdcView view = new SdcView();
    	SdcModel model = new SdcModel( view );
    	
    	assertTrue( model.convertDoubleToUnsignedLong(111117.0) >= 0 );
    	assertTrue( model.convertDoubleToUnsignedLong(25647.0) >= 0 );
    	assertTrue( model.convertDoubleToUnsignedLong(17.0e5) >= 0 );
    	assertFalse( model.convertDoubleToUnsignedLong(17.8) >= 0 );
    	
    	assertTrue( model.convertStringToUnsignedLong("26") >= 0 );
    	assertTrue( model.convertStringToUnsignedLong("179.0") >= 0 );
    	assertTrue( model.convertStringToUnsignedLong("1e4") >= 0 );
    	assertFalse( model.convertStringToUnsignedLong("17.8") >= 0 );
    	assertFalse( model.convertStringToUnsignedLong("17.8") >= 0 );
    	assertFalse( model.convertStringToUnsignedLong("-17") >= 0 );
    	assertFalse( model.convertStringToUnsignedLong("") >= 0 );
    	assertFalse( model.convertStringToUnsignedLong("abcd") >= 0 );

    }

}
